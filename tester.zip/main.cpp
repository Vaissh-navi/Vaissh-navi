#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Set {
private:
    vector<int> elements;

public:
    void insert(int data) {
        if (!contains(data)) {
            elements.push_back(data);
            sort(elements.begin(), elements.end());
        }
    }

    void remove(int data) {
        if (!elements.empty()) {
            auto it = find(elements.begin(), elements.end(), data);
            if (it != elements.end()) {
                elements.erase(it);
            }
        }
    }

    bool contains(int data) const {
        return (find(elements.begin(), elements.end(), data) != elements.end());
    }

    void unionSet(const Set& other) {
        for (int num : other.elements) {
            insert(num);
        }
        sort(elements.begin(), elements.end());
    }

    void intersection(const Set& other) {
        vector<int> temp;
        for (int num : elements) {
            if (other.contains(num)) {
                temp.push_back(num);
            }
        }
        elements = temp;
        sort(elements.begin(), elements.end());
    }

    int size() const {
        return elements.size();
    }

    void difference(const Set& other) {
        vector<int> temp;
        for (int num : elements) {
            if (!other.contains(num)) {
                temp.push_back(num);
            }
        }
        elements = temp;
        sort(elements.begin(), elements.end());
    }

    void symmetricDifference(const Set& other) {
        vector<int> temp;
        for (int num : elements) {
            if (!other.contains(num)) {
                temp.push_back(num);
            }
        }
        for (int num : other.elements) {
            if (!contains(num)) {
                temp.push_back(num);
            }
        }
        elements = temp;
        sort(elements.begin(), elements.end());
    }

    void print() const {
        for (size_t i = 0; i < elements.size(); i++) {
            cout << elements[i];
            if (i != elements.size() - 1) {
                cout << ",";
            }
        }
        cout << endl;
    }
};

int main() {
    Set* sets[100000] = { nullptr };

    int command, setNum, data;
    while (cin >> command) {
        cin >> setNum;

        if (command == 1) {
            cin >> data;
            if (sets[setNum] == nullptr) {
                sets[setNum] = new Set();
            }
            sets[setNum]->insert(data);
            cout << sets[setNum]->size() << endl;
        } else if (command == 2) {
            if (sets[setNum] == nullptr) {
                cout << -1 << endl;
            } else {
                cin >> data;
                sets[setNum]->remove(data);
                cout << sets[setNum]->size() << endl;
            }
        } else if (command == 3) {
            int result;
            cin >> data;
            if (sets[setNum] == nullptr) {
                result = -1;
            } else {
                result = sets[setNum]->contains(data) ? 1 : 0;
            }
            cout << result << endl;
        } else if (command == 4) {
            int setNum2;
            cin >> setNum2;
            if (sets[setNum] == nullptr) {
                sets[setNum] = new Set();
            }
            if (sets[setNum2] != nullptr) {
                sets[setNum]->unionSet(*sets[setNum2]);
            }
            cout << sets[setNum]->size() << endl;
        } else if (command == 5) {
            int setNum2;
            cin >> setNum2;
            if (sets[setNum] == nullptr) {
                sets[setNum] = new Set();
            }
            if (sets[setNum2] != nullptr) {
                sets[setNum]->intersection(*sets[setNum2]);
            }
            cout << sets[setNum]->size() << endl;
        } else if (command == 6) {
            if (sets[setNum] == nullptr) {
                cout << -1 << endl;
            } else {
                cout << sets[setNum]->size() << endl;
            }
        } else if (command == 7) {
            int setNum2;
            cin >> setNum2;
            if (sets[setNum] == nullptr) {
                sets[setNum] = new Set();
            }
            if (sets[setNum2] != nullptr) {
                sets[setNum]->difference(*sets[setNum2]);
            }
            cout << sets[setNum]->size() << endl;
        } else if (command == 8) {
            int setNum2;
            cin >> setNum2;
            if (sets[setNum] == nullptr) {
                sets[setNum] = new Set();
            }
            if (sets[setNum2] != nullptr) {
                sets[setNum]->symmetricDifference(*sets[setNum2]);
            }
            cout << sets[setNum]->size() << endl;
        } else if (command == 9) {
            if (sets[setNum] == nullptr) {
                cout << endl;
            } else {
                sets[setNum]->print();
            }
        } else if (command == 0) {
            break;
        }
    }

    for (int i = 0; i < 100000; i++) {
        delete sets[i];
    }

    return 0;
}
